// ============================================================
//                  AQUA SENTINEL V2
//       PATROL + MONITOR + ALERT + MANUAL CONTROL
// ============================================================

// ================= MOTOR PINS =================

#define LEFT_STEP   14
#define LEFT_DIR    13

#define RIGHT_STEP  33
#define RIGHT_DIR   27


// ================= SERVO =================

#define SERVO_PIN 25

#define SERVO_FREQUENCY 50
#define SERVO_RESOLUTION 16


// ================= ULTRASONIC =================

#define TRIG_PIN 5
#define ECHO_PIN 18


// ================= DHT22 =================

#include "DHT.h"

#define DHT_PIN 4
#define DHT_TYPE DHT22

DHT dht(DHT_PIN, DHT_TYPE);


// ================= OLED =================

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define OLED_SDA 21
#define OLED_SCL 22

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

Adafruit_SSD1306 display(
  SCREEN_WIDTH,
  SCREEN_HEIGHT,
  &Wire,
  -1
);


// ================= POTENTIOMETER =================

#define POT_PIN 34


// ================= SETTINGS =================

#define OBSTACLE_DISTANCE 20

#define STEP_DELAY 2000


// ================= ROBOT MODE =================

char robotMode = 'A';


// ============================================================
// SERVO
// ============================================================

void moveServo(int angle) {

  int pulseWidth = map(
    angle,
    0,
    180,
    500,
    2400
  );

  uint32_t duty =
    (uint32_t)pulseWidth *
    65535 /
    20000;

  ledcWrite(
    SERVO_PIN,
    duty
  );

  delay(400);
}


// ============================================================
// ULTRASONIC
// ============================================================

float getDistance() {

  digitalWrite(
    TRIG_PIN,
    LOW
  );

  delayMicroseconds(2);

  digitalWrite(
    TRIG_PIN,
    HIGH
  );

  delayMicroseconds(10);

  digitalWrite(
    TRIG_PIN,
    LOW
  );

  long duration =
    pulseIn(
      ECHO_PIN,
      HIGH,
      30000
    );

  if (duration == 0) {

    return 999;
  }

  return duration * 0.0343 / 2;
}


// ============================================================
// MOTOR CONTROL
// ============================================================

void moveMotors(
  int leftSteps,
  int rightSteps
) {

  int leftCount =
    abs(leftSteps);

  int rightCount =
    abs(rightSteps);

  int maxSteps =
    max(
      leftCount,
      rightCount
    );


  digitalWrite(
    LEFT_DIR,
    leftSteps >= 0
      ? HIGH
      : LOW
  );

  digitalWrite(
    RIGHT_DIR,
    rightSteps >= 0
      ? HIGH
      : LOW
  );


  for (
    int i = 0;
    i < maxSteps;
    i++
  ) {

    if (i < leftCount) {

      digitalWrite(
        LEFT_STEP,
        HIGH
      );
    }

    if (i < rightCount) {

      digitalWrite(
        RIGHT_STEP,
        HIGH
      );
    }

    delayMicroseconds(
      STEP_DELAY
    );

    digitalWrite(
      LEFT_STEP,
      LOW
    );

    digitalWrite(
      RIGHT_STEP,
      LOW
    );

    delayMicroseconds(
      STEP_DELAY
    );
  }
}


// ============================================================
// MOVEMENT FUNCTIONS
// ============================================================

void moveForward() {

  Serial.println(
    "FORWARD"
  );

  moveMotors(
    20,
    20
  );
}


void moveBackward() {

  Serial.println(
    "BACKWARD"
  );

  moveMotors(
    -20,
    -20
  );
}


void turnLeft() {

  Serial.println(
    "TURNING LEFT"
  );

  moveMotors(
    -50,
    50
  );
}


void turnRight() {

  Serial.println(
    "TURNING RIGHT"
  );

  moveMotors(
    50,
    -50
  );
}


void stopRobot() {

  Serial.println(
    "STOP"
  );

  digitalWrite(
    LEFT_STEP,
    LOW
  );

  digitalWrite(
    RIGHT_STEP,
    LOW
  );
}


// ============================================================
// SENSOR READING
// ============================================================

void readSensors(
  float &temperature,
  float &humidity,
  int &waterLevel
) {

  temperature =
    dht.readTemperature();

  humidity =
    dht.readHumidity();

  int potValue =
    analogRead(
      POT_PIN
    );

  waterLevel =
    map(
      potValue,
      0,
      4095,
      0,
      100
    );


  if (isnan(temperature)) {

    temperature = 0;
  }

  if (isnan(humidity)) {

    humidity = 0;
  }
}


// ============================================================
// DETERMINE ALERT
// ============================================================

String getAlert(
  float temperature,
  float humidity,
  int waterLevel
) {

  if (temperature > 50) {

    return "HIGH TEMP!";
  }

  if (humidity > 85) {

    return "HIGH HUMIDITY!";
  }

  if (waterLevel <= 20) {

    return "LOW WATER!";
  }

  return "NORMAL";
}


// ============================================================
// OLED
// ============================================================

void showDashboard(
  float temperature,
  float humidity,
  int waterLevel,
  float distance,
  String status
) {

  display.clearDisplay();

  display.setTextColor(
    SSD1306_WHITE
  );

  display.setTextSize(1);


  display.setCursor(
    0,
    0
  );

  display.println(
    "AQUA SENTINEL"
  );


  display.drawLine(
    0,
    9,
    127,
    9,
    SSD1306_WHITE
  );


  display.setCursor(
    0,
    12
  );

  display.print(
    "T:"
  );

  display.print(
    temperature,
    1
  );

  display.print(
    "C H:"
  );

  display.print(
    humidity,
    0
  );

  display.println(
    "%"
  );


  display.setCursor(
    0,
    23
  );

  display.print(
    "WATER: "
  );

  display.print(
    waterLevel
  );

  display.println(
    "%"
  );


  display.setCursor(
    0,
    34
  );

  display.print(
    "DIST: "
  );

  if (distance >= 999) {

    display.println(
      "---"
    );

  } else {

    display.print(
      distance,
      0
    );

    display.println(
      " cm"
    );
  }


  display.setCursor(
    0,
    45
  );

  display.print(
    "MODE: "
  );

  display.println(
    robotMode == 'A'
      ? "PATROL"
      : robotMode == 'M'
        ? "MONITOR"
        : "MANUAL"
  );


  display.setCursor(
    0,
    56
  );

  display.print(
    status
  );


  display.display();
}


// ============================================================
// SERIAL COMMANDS
// ============================================================

void processCommand() {

  if (!Serial.available()) {

    return;
  }

  char command =
    Serial.read();

  command =
    toupper(command);


  switch (command) {

    // --------------------------
    // AUTONOMOUS
    // --------------------------

    case 'A':

      robotMode = 'A';

      Serial.println(
        "MODE: AUTONOMOUS PATROL"
      );

      break;


    // --------------------------
    // MONITOR
    // --------------------------

    case 'M':

      robotMode = 'M';

      stopRobot();

      Serial.println(
        "MODE: MONITOR"
      );

      break;


    // --------------------------
    // MANUAL
    // --------------------------

    case 'F':

      robotMode = 'X';

      moveForward();

      break;


    case 'B':

      robotMode = 'X';

      moveBackward();

      break;


    case 'L':

      robotMode = 'X';

      turnLeft();

      break;


    case 'R':

      robotMode = 'X';

      turnRight();

      break;


    case 'S':

      robotMode = 'X';

      stopRobot();

      break;


    default:

      break;
  }
}


// ============================================================
// PATROL MODE
// ============================================================

void patrolMode() {

  float temperature;
  float humidity;
  int waterLevel;

  readSensors(
    temperature,
    humidity,
    waterLevel
  );


  float distance;

  moveServo(90);

  distance =
    getDistance();


  String alert =
    getAlert(
      temperature,
      humidity,
      waterLevel
    );


  Serial.println();

  Serial.println(
    "------------------------------"
  );


  Serial.print(
    "Temperature: "
  );

  Serial.print(
    temperature
  );

  Serial.println(
    " C"
  );


  Serial.print(
    "Humidity: "
  );

  Serial.print(
    humidity
  );

  Serial.println(
    " %"
  );


  Serial.print(
    "Water Level: "
  );

  Serial.print(
    waterLevel
  );

  Serial.println(
    "%"
  );


  Serial.print(
    "Distance: "
  );

  Serial.print(
    distance
  );

  Serial.println(
    " cm"
  );


  // --------------------------
  // ALERT
  // --------------------------

  if (alert != "NORMAL") {

    Serial.print(
      "ALERT: "
    );

    Serial.println(
      alert
    );


    showDashboard(
      temperature,
      humidity,
      waterLevel,
      distance,
      alert
    );
  }


  // --------------------------
  // PATH CLEAR
  // --------------------------

  if (
    distance >
    OBSTACLE_DISTANCE
  ) {

    Serial.println(
      "PATH CLEAR - MOVING"
    );


    showDashboard(
      temperature,
      humidity,
      waterLevel,
      distance,
      alert
    );


    moveForward();

    return;
  }


  // --------------------------
  // OBSTACLE
  // --------------------------

  Serial.println(
    "!!! OBSTACLE DETECTED !!!"
  );

  stopRobot();


  delay(300);


  // --------------------------
  // LEFT SCAN
  // --------------------------

  Serial.println(
    "SCANNING LEFT..."
  );

  moveServo(150);

  float leftDistance =
    getDistance();


  Serial.print(
    "LEFT: "
  );

  Serial.print(
    leftDistance
  );

  Serial.println(
    " cm"
  );


  // --------------------------
  // RIGHT SCAN
  // --------------------------

  Serial.println(
    "SCANNING RIGHT..."
  );

  moveServo(30);

  float rightDistance =
    getDistance();


  Serial.print(
    "RIGHT: "
  );

  Serial.print(
    rightDistance
  );

  Serial.println(
    " cm"
  );


  moveServo(90);


  // --------------------------
  // DECISION
  // --------------------------

  if (
    leftDistance >
    rightDistance
  ) {

    showDashboard(
      temperature,
      humidity,
      waterLevel,
      distance,
      "TURN LEFT"
    );

    turnLeft();

  }

  else if (
    rightDistance >
    leftDistance
  ) {

    showDashboard(
      temperature,
      humidity,
      waterLevel,
      distance,
      "TURN RIGHT"
    );

    turnRight();

  }

  else {

    showDashboard(
      temperature,
      humidity,
      waterLevel,
      distance,
      "TURN LEFT"
    );

    turnLeft();
  }


  delay(300);
}


// ============================================================
// MONITOR MODE
// ============================================================

void monitorMode() {

  float temperature;
  float humidity;
  int waterLevel;

  readSensors(
    temperature,
    humidity,
    waterLevel
  );


  float distance =
    getDistance();


  String alert =
    getAlert(
      temperature,
      humidity,
      waterLevel
    );


  Serial.println();

  Serial.println(
    "===== MONITOR MODE ====="
  );


  Serial.print(
    "Temperature: "
  );

  Serial.print(
    temperature
  );

  Serial.println(
    " C"
  );


  Serial.print(
    "Humidity: "
  );

  Serial.print(
    humidity
  );

  Serial.println(
    " %"
  );


  Serial.print(
    "Water Level: "
  );

  Serial.print(
    waterLevel
  );

  Serial.println(
    "%"
  );


  Serial.print(
    "Distance: "
  );

  Serial.print(
    distance
  );

  Serial.println(
    " cm"
  );


  Serial.print(
    "STATUS: "
  );

  Serial.println(
    alert
  );


  showDashboard(
    temperature,
    humidity,
    waterLevel,
    distance,
    alert
  );


  delay(1000);
}


// ============================================================
// SETUP
// ============================================================

void setup() {

  Serial.begin(
    115200
  );


  // Motors

  pinMode(
    LEFT_STEP,
    OUTPUT
  );

  pinMode(
    LEFT_DIR,
    OUTPUT
  );

  pinMode(
    RIGHT_STEP,
    OUTPUT
  );

  pinMode(
    RIGHT_DIR,
    OUTPUT
  );


  // Ultrasonic

  pinMode(
    TRIG_PIN,
    OUTPUT
  );

  pinMode(
    ECHO_PIN,
    INPUT
  );


  // Potentiometer

  pinMode(
    POT_PIN,
    INPUT
  );


  // DHT

  dht.begin();


  // Servo

  ledcAttach(
    SERVO_PIN,
    SERVO_FREQUENCY,
    SERVO_RESOLUTION
  );


  // OLED

  Wire.begin(
    OLED_SDA,
    OLED_SCL
  );


  if (
    !display.begin(
      SSD1306_SWITCHCAPVCC,
      0x3C
    )
  ) {

    Serial.println(
      "OLED ERROR!"
    );

    while (true);
  }


  moveServo(90);


  // Startup screen

  display.clearDisplay();

  display.setTextColor(
    SSD1306_WHITE
  );

  display.setTextSize(2);

  display.setCursor(
    5,
    5
  );

  display.println(
    "AQUA"
  );

  display.setCursor(
    5,
    30
  );

  display.println(
    "SENTINEL"
  );

  display.display();


  delay(2000);


  Serial.println();

  Serial.println(
    "================================"
  );

  Serial.println(
    "       AQUA SENTINEL V2"
  );

  Serial.println(
    "================================"
  );

  Serial.println(
    "A = AUTONOMOUS PATROL"
  );

  Serial.println(
    "M = MONITOR"
  );

  Serial.println(
    "F = FORWARD"
  );

  Serial.println(
    "B = BACKWARD"
  );

  Serial.println(
    "L = LEFT"
  );

  Serial.println(
    "R = RIGHT"
  );

  Serial.println(
    "S = STOP"
  );

  Serial.println(
    "================================"
  );
}


// ============================================================
// MAIN LOOP
// ============================================================

void loop() {

  // Always listen for commands

  processCommand();


  // --------------------------
  // AUTONOMOUS
  // --------------------------

  if (robotMode == 'A') {

    patrolMode();
  }


  // --------------------------
  // MONITOR
  // --------------------------

  else if (robotMode == 'M') {

    monitorMode();
  }


  // --------------------------
  // MANUAL
  // --------------------------

  else {

    delay(50);
  }
}